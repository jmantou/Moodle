<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * local practice's index page
 *
 * @package    local_plugina
 * @copyright  2024 onwards WIDE Services  {@link https://www.wideservices.gr}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
use local_plugina\output\main;

require(__DIR__ . '/../../config.php');
require_once(__DIR__ . '/forms/plugina_form.php');

// require_login();

$url = new moodle_url('/local/plugina/index.php');
$PAGE->set_url($url);
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');

$PAGE->set_title(get_string('pluginname', 'local_plugina'));
$PAGE->set_heading(get_string('pluginname', 'local_plugina'));

// echo $OUTPUT->header();

// Display the Registration Form
$mform = new plugina_form(null);


$mform = new plugina_form(null);
$fromform = $mform->get_data();
if ($fromform) {

    // Generating temporary password
    $temporarypassword = generate_password(); 

    // Email Content
    $subject = 'Email Verification';
    $message = "Dear {$fromform->firstname},\n";
    $message .= "Thank you for registering. Your temporary password is: {$temporarypassword}\n\n";
    $message .= "Please use this temporary password to login to your account.\n\n";
    $message .= "After the first login please change your password with a new one.\n\n";
    $message .= "Regards,\nWide Services Team";

    // Email Parameters
    $emailparams = [
        'subject' => $subject,
        'message' => $message,
        'email' => $fromform->email,
    ];
    $emailfrom = 'gmantds@gmail.com';
    $emailreplyto = 'gmantds@gmail.com';
    $plaintextmessage = 'Thank you for registering. Your temporary password is: ... bla bla';
    email_to_user($emailparams, $emailfrom, $emailreplyto, $plaintextmessage);

    // Inserting Form Values to Database
    $insertrecord = new stdClass();
    $insertrecord->firstname = $fromform->firstname;
    $insertrecord->lastname = $fromform->lastname;
    $insertrecord->email = $fromform->email;
    $insertrecord->country = $fromform->country;
    $insertrecord->mobile = $fromform->mobile;
    $insertrecord->timecreated = time() - 86400;
    $insertrecord->timemodified = time();

    $DB->insert_record('local_plugina', $insertrecord);
    redirect(new moodle_url('/local/plugina/index.php'));    
} else {
    echo $OUTPUT->header();
    $mform->display();
    echo $OUTPUT->footer();
}




